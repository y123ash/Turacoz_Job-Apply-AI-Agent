import json
import re

from ae.utils.logger import logger


def escape_js_message(message: str) -> str:
    return json.dumps(message)


def beautify_plan_message(message:str) -> str:
    logger.debug(f"beautify_plan_message original:\n{message}")
    # Add a newline before each numbered step that is not already preceded by a newline
    plan_with_newlines = re.sub(r'(?<!\n)( \d+\.)', r'\n\1', message)
    logger.debug(f"beautify_plan_message modified:\n{plan_with_newlines}")
    return plan_with_newlines
