
import json
import re
from typing import Any


def str_to_bool(s: str | bool) -> bool:
    if isinstance(s, bool):
        return s
    return s.lower() in ['true', '1', 't', 'y', 'yes']

def str_to_json(s: str) -> dict[str, Any] | None:
    s_fixed = re.sub(r'(?<!\\)\n', '\\n', s) 
    try:
        obj = json.loads(s_fixed)
        return obj
    except json.JSONDecodeError as e:
        return None

def is_terminating_message(message: str) -> bool:
    message_as_json = str_to_json(message)
    if message_as_json is None:
        if message.find('"terminate": "yes"') != -1:
            return True
        return False
    else:
        return message_as_json.get("terminate") == "yes"
