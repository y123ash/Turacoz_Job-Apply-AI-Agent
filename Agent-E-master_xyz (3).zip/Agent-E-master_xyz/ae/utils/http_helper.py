from typing import Any

import requests


def make_post_request(url: str, data: dict[str, Any], api_key: str, api_key_header_name: str = "apikey") -> dict[str, Any]|None:
    headers = {
        'Content-Type': 'application/json',
        api_key_header_name: api_key
    }

    try:
        response = requests.post(url, json=data, headers=headers)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")
        return None
    except ValueError:
        print("Error: Response is not in JSON format")
        return None
