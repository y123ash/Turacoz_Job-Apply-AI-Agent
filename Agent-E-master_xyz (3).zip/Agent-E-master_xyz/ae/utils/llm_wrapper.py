import os
import requests

def query_llm_mixtral(prompt: str, temperature: float = 0.1, max_tokens: int = 256) -> str:
    """Query the RapidAPI LLM (Mixtral) and return the response text."""
    api_key = os.environ.get("AUTOGEN_MODEL_API_KEY", "")  # RapidAPI key
    base_url = os.environ.get("AUTOGEN_MODEL_BASE_URL", "https://llm-api1.p.rapidapi.com/v0/llmchat")
    model_name = os.environ.get("AUTOGEN_MODEL_NAME", "")   # e.g. "mistral" or "gpt-4-turbo"
    # Prepare request payload
    payload = {"prompt": prompt, "temperature": temperature, "max_tokens": max_tokens}
    if model_name:
        payload["model"] = model_name
    headers = {
        "Content-Type": "application/json",
        "X-RapidAPI-Key": api_key,
        "X-RapidAPI-Host": "llm-api1.p.rapidapi.com"
    }
    try:
        resp = requests.post(base_url, json=payload, headers=headers, timeout=60)
        resp.raise_for_status()
    except Exception as e:
        raise RuntimeError(f"RapidAPI LLM request failed: {e}")
    # Parse response (handle JSON or plain text)
    try:
        data = resp.json()
    except ValueError:
        return resp.text.strip()
    # Return content from JSON response (supports various response formats)
    if isinstance(data, dict):
        if "content" in data:        # direct content
            return data["content"]
        if "message" in data:        # single message
            return data["message"]
        if "choices" in data:        # OpenAI-like format
            choices = data["choices"]
            if choices:
                # if choices[0] has message content (OpenAI chat format)
                if isinstance(choices[0], dict):
                    msg = choices[0].get("message") or {}
                    if "content" in msg:
                        return msg["content"]
                    # or if text field present (e.g. completion models)
                    if "text" in choices[0]:
                        return choices[0]["text"]
                else:
                    return str(choices[0])
    # Fallback to raw text if no known fields
    return resp.text.strip()