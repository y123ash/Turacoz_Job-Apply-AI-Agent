import logging
import os

from dotenv import load_dotenv
from pythonjsonlogger import jsonlogger
load_dotenv()

logger = logging.getLogger(__name__)

# Custom function to configure the logger
def configure_logger(level: str = "INFO") -> None:
    log_format = os.getenv("LOG_MESSAGES_FORMAT", "text").lower()

    # Set log level for the main logger
    logger.setLevel(level.upper())

    # Create a handler for logging
    handler = logging.StreamHandler()

    if log_format == "json":
        # JSON format
        formatter = jsonlogger.JsonFormatter(
            fmt='%(asctime)s %(name)s %(levelname)s %(message)s %(filename)s %(lineno)d',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
    else:
        # Text format
        formatter = logging.Formatter(
            fmt='[%(asctime)s] %(levelname)s {%(filename)s:%(lineno)d} - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )

    handler.setFormatter(formatter)
    logger.handlers = [] 
    logger.addHandler(handler)
    http_loggers = []
    for http_logger in http_loggers:
        lib_logger = logging.getLogger(http_logger)
        lib_logger.setLevel(logging.DEBUG)
        lib_logger.handlers = [] 
        lib_logger.addHandler(handler)  
configure_logger(level="INFO")

def set_log_level(level: str) -> None:
    configure_logger(level)

logging.getLogger("matplotlib.pyplot").setLevel(logging.WARNING)
logging.getLogger("PIL.PngImagePlugin").setLevel(logging.WARNING)
logging.getLogger("PIL.Image").setLevel(logging.WARNING)

__all__ = ["logger", "set_log_level"]
