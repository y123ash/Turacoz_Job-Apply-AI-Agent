import os
from typing import Any
from xmlrpc.client import ResponseError

from ae.utils.llm_wrapper import query_llm_mixtral
from dotenv import load_dotenv


class OpenAILLMHelper:
    def __init__(self):
        load_dotenv()
        async def get_chat_completion_response_async(self, system_msg:str, user_msgs:list[str], temperature:float=0.1, max_tokens:int=256, frequency_penalty:float=0.0, top_p: float=1.0, top_k: int=1, presence_penalty: float=0.0):
        formatted_msgs: list[dict[str, Any]] = [{"role": "system", "content": system_msg}]

        for user_msg in user_msgs:
            formatted_msgs.append({"role": "user", "content": user_msg})

        flat_prompt=""

        for msg in formatted_msgs:
            flat_prompt += f"{msg['role'].capitalize()}: {msg['content']}\n"

        try:
            import asyncio
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None, query_llm_mixtral, flat_prompt, temperature, max_tokens
            )
            print(">>> openai response:", response)

            print(response)

        except Exception as e:
            print("❌ The LLM call failed:")
            print(e)
            raise Exception(f"Calling MiXtral LLM failed. Error: {e}") from e 

        return  response 