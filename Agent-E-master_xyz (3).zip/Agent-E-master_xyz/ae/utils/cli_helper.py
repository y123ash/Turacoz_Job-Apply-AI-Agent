import asyncio
from asyncio import Future


def async_input(prompt: str) -> Future: # type: ignore
    loop = asyncio.get_event_loop()
    return loop.run_in_executor(None, input, prompt)


async def answer_questions_over_cli(questions: list[str]) -> dict[str, str]:
    answers: dict[str, str] = {}
    print("*********************************")
    for question in questions:
        answers[question] = await async_input("Question: "+str(question)+" : ")
    print("*********************************")
    return answers
