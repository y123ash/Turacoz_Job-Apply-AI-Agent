import asyncio
from ae.core.system_orchestrator import SystemOrchestrator

def main():
    """Main entry point for the Agent-E console script."""
    orchestrator = SystemOrchestrator(
        agent_scenario="user,planner_agent,browser_nav_agent,browser_nav_executor",
        input_mode="GUI_ONLY"
    )
    asyncio.run(orchestrator.start())

if __name__ == "__main__":
    main()  # Call the main function when running the script directly