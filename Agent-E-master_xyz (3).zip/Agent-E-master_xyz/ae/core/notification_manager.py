from collections.abc import Callable


class NotificationManager:

    def __init__(self):
        """
        Initialize the NotificationManager with no listeners.
        """
        self.listeners: list[Callable[[dict[str, str]], None]] = []

    def notify(self, message: str, message_type: str) -> None:
        notification = {
            "message": message,
            "type": message_type,
        }

        if self.listeners:
            for listener in self.listeners:
                listener(notification)
        else:
            print(f"No listeners available, discarding message: {notification}")

    def register_listener(self, listener: Callable[[dict[str, str]], None]) -> None:
        self.listeners.append(listener)

    def unregister_listener(self, listener: Callable[[dict[str, str]], None]) -> None:
        self.listeners.remove(listener)
