import re
from collections import Counter

def extract_keywords(text: str, top_n: int = 10) -> list[str]:
    """Extract top keywords from the given text (e.g., resume content)."""
    # Split text into words and filter out common stopwords
    words = re.findall(r'\w+', text.lower())
    stopwords = {
        "the","and","for","with","this","that","from","into","to","in","on","at","by",
        "a","an","is","it","of","or","as","if","but","be","are","not","your","you"
    }
    keywords = [w for w in words if len(w) > 2 and w not in stopwords and not w.isdigit()]
    # Get the most frequent words as keywords
    most_common = [word for word, _ in Counter(keywords).most_common(top_n)]
    return most_common