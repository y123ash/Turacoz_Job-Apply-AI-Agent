import asyncio
from typing import Any

import autogen  # type: ignore

from ae.core.playwright_manager import PlaywrightManager
from ae.utils.logger import logger
from ae.utils.ui_messagetype import MessageType


def final_reply_callback_user_proxy(recipient: autogen.ConversableAgent, messages: list[dict[str, Any]], sender: autogen.Agent, config: dict[str, Any]):
    global last_agent_response
    last_message = messages[-1]
    logger.debug(f"Post Process Message (User Proxy):{last_message}")
    if last_message.get('content') and "##TERMINATE##" in last_message['content']:
        last_agent_response = last_message['content'].replace("##TERMINATE##", "").strip()
        if last_agent_response:
            logger.debug("*****Final Reply*****")
            logger.debug(f"Final Response: {last_agent_response}")
            logger.debug("*********************")
            return True, None

    return False, None

def final_reply_callback_planner_agent(message:str, message_type:MessageType = MessageType.STEP): # type: ignore
        browser_manager = PlaywrightManager(browser_type='chromium', headless=False)
        loop = asyncio.get_event_loop()
        loop.run_until_complete(browser_manager.notify_user(message, message_type=message_type))
        return False, None  # required to ensure the agent communication flow continues