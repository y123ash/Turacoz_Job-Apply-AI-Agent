import os
import traceback

from playwright.async_api import Frame
from playwright.async_api import Page

from ae.config import PROJECT_SOURCE_ROOT
from ae.utils.js_helper import escape_js_message
from ae.utils.logger import logger
from ae.utils.ui_messagetype import MessageType


class UIManager:

    overlay_is_collapsed: bool = True

    overlay_processing_state: str = "init"  #init: initialised, processing: processing is ongoing, done: processing is done
    overlay_show_details:bool = True

    conversation_history:list[dict[str, str]] = []
    __update_overlay_chat_history_running: bool = False


    def __init__(self):
        self.add_default_system_messages()


    async def handle_navigation(self, frame: Frame):
        try:
            await frame.wait_for_load_state("load")
            overlay_injection_file = os.path.join(PROJECT_SOURCE_ROOT, "ui", "injectOverlay.js")
            with open(overlay_injection_file, 'r') as file:  # noqa: UP015
                js_code = file.read()

            # Inject the JavaScript code into the page
            await frame.evaluate(js_code)
            js_bool = str(self.overlay_show_details).lower()
            if self.overlay_is_collapsed:
                await frame.evaluate(f"showCollapsedOverlay('{self.overlay_processing_state}', {js_bool});")
            else:
                await frame.evaluate(f"showExpandedOverlay('{self.overlay_processing_state}', {js_bool});")

            #update chat history in the overlay
            await self.update_overlay_chat_history(frame)

        except Exception as e:
            if "Frame was detached" not in str(e):
                raise e


    async def show_overlay(self, page: Page):
        if not self.overlay_is_collapsed:
            logger.debug("Overlay is already expanded, ignoring show_overlay call")
            return
        await page.evaluate("showExpandedOverlay();")
        self.overlay_is_collapsed = True


    def update_overlay_state(self, is_collapsed: bool):
        self.overlay_is_collapsed = is_collapsed



    async def update_overlay_show_details(self, show_details: bool, page: Page):
        self.overlay_show_details = show_details
        await self.update_overlay_chat_history(page)


    async def update_processing_state(self, state: str, page: Page):
        self.overlay_processing_state = state
        try:
            js_bool = str(self.overlay_is_collapsed).lower()
            await page.evaluate(f"updateOverlayState('{self.overlay_processing_state}', {js_bool});")
        except Exception as e:
            logger.debug(f"JavaScript error: {e}")

    async def update_overlay_chat_history(self, frame_or_page: Frame | Page):
        logger.debug("Updating overlay chat history")

        if self.overlay_is_collapsed:
            logger.debug("Overlay is collapsed, not updating chat history")
            return
        if self.__update_overlay_chat_history_running:
            logger.debug("update_overlay_chat_history is already running, returning" + frame_or_page.url)
            return

        self.__update_overlay_chat_history_running = True
        #update chat history in the overlay by removing all messages and adding them again fresh
        try:
            await frame_or_page.evaluate("clearOverlayMessages();")
            for message in self.conversation_history:
                safe_message = escape_js_message(message["message"])
                safe_message_type = escape_js_message(message.get("message_type", MessageType.STEP.value))
                if message["from"] == "user":
                    await frame_or_page.evaluate(f"addUserMessage({safe_message});")
                else:
                   #choose chich message types to be shown depending on UI setting
                    if self.overlay_show_details == False:  # noqa: E712
                        if message["message_type"] not in (MessageType.PLAN.value, MessageType.QUESTION.value, MessageType.ANSWER.value, MessageType.INFO.value):
                            continue
                    else:
                        if message["message_type"] not in (MessageType.PLAN.value,  MessageType.QUESTION.value , MessageType.ANSWER.value,  MessageType.INFO, MessageType.STEP.value):
                            continue

                    js_code = f"addSystemMessage({safe_message}, is_awaiting_user_response=false, message_type={safe_message_type});"
                    await frame_or_page.evaluate(js_code)
            logger.debug("Chat history updated in overlay, removing update lock flag")
        except Exception:
            traceback.print_exc()
        finally:
            self.__update_overlay_chat_history_running = False

    def clear_conversation_history(self):
        self.conversation_history = []
        self.add_default_system_messages()

    def get_conversation_history(self):
        return self.conversation_history


    def new_user_message(self, message: str):

        self.conversation_history.append({"from":"user", "message":message})


    def new_system_message(self, message: str, type:MessageType=MessageType.STEP):

        self.conversation_history.append({"from":"system", "message":message, "message_type":type.value})
        print(f"Adding system message: {message}")

    def add_default_system_messages(self):
        pass

    async def command_completed(self, page: Page, command: str, elapsed_time: float|None = None):
        if not self.overlay_is_collapsed:
            await page.evaluate("focusOnOverlayInput();")
            await page.evaluate("commandExecutionCompleted();")
