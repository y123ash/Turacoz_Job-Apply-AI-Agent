from setuptools import setup, find_packages

setup(
    name="Agent-E",
    version="0.1.0",
    description="Automation tool for agents to perform tasks starting with the web browser.",
    packages=find_packages(),  # Finds the 'ae' package and sub-packages automatically
    install_requires=[
        "anthropic>=0.23.1",
        "google-generativeai==0.5.1",
        "nltk==3.8.1",
        "pdfplumber==0.11.1",
        "playwright==1.44.0",
        "autogen~=0.7",
        "autogen[anthropic]~=0.7",
        "autogen[groq]~=0.7",
        "pydantic==2.6.2",
        "python-dotenv==1.0.0",
        "tabulate==0.9.0",
        "nest-asyncio==1.6.0",
        "fastapi==0.111.1",
        "uvicorn==0.30.3",
        "python-json-logger==2.0.7"
    ],
    entry_points={
        "console_scripts": [
            "run = ae.main:main"
        ]
    }
)