import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from nltk.tokenize import word_tokenize  # type: ignore
#from openai import OpenAI

load_dotenv()
#client = OpenAI()


def llm_fuzzy_match(pred: str, reference: str, question: str) -> float:
    messages: list[dict[str, Any]] = []
    # construct the question to ask
    message = "Help a teacher to grade the answer of a student given a question. Keep in mind that the student may use different phrasing or wording to answer the question. The goal is to evaluate whether the answer is semantically equivalent to the reference answer.\n"
    message += f"question: {question}\n"
    message += f"reference answer: {reference}\n"
    message += "all the string 'N/A' that you see is a special sequence that means 'not achievable'\n"
    message += f"student answer: {pred}\n"
    message += "Conclude the judgement by correct/incorrect/partially correct."
    messages = [
        {"role": "system", "content": "You are a helpful assistant"},
        {"role": "user", "content": message},
    ]

    from ae.utils.llm_wrapper import query_llm_mixtral
    def llm_fuzzy_match(pred: str, reference: str, question: str) -> float:
        # Combine everything into a single prompt
        prompt = f"""You are a helpful assistant.

        Evaluate this answer:

        Question: {question}
        Answer: {pred}
        Reference Answer: {reference}

        Respond with one of the following:
        - "correct"
        - "partially correct"
        - "incorrect"
    """

        response = query_llm_mixtral(prompt, temperature=0, max_tokens=100).lower()

        if "partially correct" in response or "incorrect" in response:
            return 0.0
        else:
            assert "correct" in response
            return 1.0



def llm_ua_match(pred: str, reference: str, question: str) -> float:
    messages: list[dict[str, Any]] = []
    # construct the question to ask
    message = ""
    message += f"task: {question}\n"
    message += f"actual unachievable reason: {reference}\n"
    message += f"reported unachievable reason: {pred}\n"
    message += (
        "The task described above is inherently unachievable due to the reason specified under 'actual unachievable reason'. "
        "An individual previously attempted this task and was unable to complete it. They provided a reason for their failure, "
        "which is listed under 'reported unachievable reason'. Your role is to review both the actual and reported reasons. "
        "Determine if the reported reason aligns with the actual reason, even if implicitly. "
        "If the stated reason is in line with the actual reason, respond with 'same'. Otherwise, respond with 'different'."
    )
    messages = [
        {"role": "system", "content": "You are a helpful assistant"},
        {"role": "user", "content": message},
    ]

    response = generate_from_openai_chat_completion(
        model="gpt-4-turbo-preview",
        messages=messages,
        temperature=0,
        max_tokens=768,
        top_p=1.0,
        context_length=0,
    ).lower()
    if "different" in response:
        return 0.0
    else:
        assert "same" in response
        return 1.0

from llm_wrapper import query_llm_mixtral 

def generate_from_openai_chat_completion(
    messages: list[dict[str, str]],
    model: str,
    temperature: float,
    max_tokens: int,
    top_p: float,
    context_length: int,
    stop_token: str | None = None,
) -> str:
    

def clean_answer(answer: str) -> str:
    answer = answer.strip().strip('"').strip("'").lower()
    return answer

def evaluate_exact_match(ref: str, pred: str) -> float:
    return float(clean_answer(pred) == clean_answer(ref))

def evaluate_must_include(ref: str, pred: str, tokenize: bool = False) -> float:
    clean_ref = clean_answer(ref)
    clean_pred = clean_answer(pred)
    if tokenize and len(clean_ref) == 1:
        return float(clean_ref in word_tokenize(clean_pred))
    else:
        return float(clean_ref in clean_pred)

def evaluate_fuzzy_match(ref: str, pred: str, intent: str) -> float:
    return llm_fuzzy_match(pred, ref, intent)

def evaluate_ua_match(ref: str, pred: str, intent: str) -> float:
    return llm_ua_match(pred, ref, intent)


def load_config(config_file: Path | str) -> list[dict[str, Any]]:
    with open(config_file, "r") as f:  # noqa: UP015
        configs = json.load(f)
    return configs

def task_config_validator(task_config: dict[str, Any]) -> bool:
    # Access the attributes
    command = task_config.get('intent')

    if not command:
        raise ValueError("Intent is missing in the task config file. Without it the task cannot be run.")

    return True

def get_formatted_current_timestamp(format: str = "%Y-%m-%d %H:%M:%S") -> str:
    # Get the current time
    current_time = datetime.now()

    # Format the timestamp as a human-readable string
    timestamp_str = current_time.strftime(format)
    return timestamp_str
