import os
import sys

project = 'Agent-E'
copyright = '2024, Merlyn Mind Inc'
author = 'Merlyn Mind Inc'

extensions = ['sphinx.ext.autodoc', 'sphinx.ext.napoleon']

templates_path = ['_templates']
exclude_patterns = ['_build', 'Thumbs.db', '.DS_Store']

html_theme = 'sphinx_rtd_theme'
html_static_path = ['_static']

sys.path.insert(0, os.path.abspath('..'))
